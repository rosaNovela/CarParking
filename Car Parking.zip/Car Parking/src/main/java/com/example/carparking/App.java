package com.example.carparking;

import com.example.carparking.database.JdbcSQLiteConnection;
import io.javalin.Javalin;

public class App {

    public static void main(String[] args) {
        Javalin server = Javalin.create(config -> {
            config.staticFiles.add("/public");
        }).start(7070);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        db.connectToDB();
        server.get("/", context -> context.redirect("index.html"));
        server.post("/login", LoginHandler::login);
        server.post("/signup", LoginHandler::signup);
        server.get("/signup", context -> context.redirect("signup.html"));
        server.post("/signup_web", LoginHandler::signupWeb);
        server.post("/signin", context -> context.redirect("test.html"));
        server.post("/booking", BookingHandler::getBooking);
        server.post("/add_booking", BookingHandler::addBooking);
        server.post("/car", CarHandler::getCar);
        server.post("/add_car", CarHandler::addCar);
        server.post("/login_web", LoginHandler::loginweb);
        server.post("/user_data_web", HomePageHandler::getData);
    }
}

package com.example.carparking;

import com.example.carparking.bean.*;
import com.example.carparking.bean.Error;
import com.example.carparking.database.JdbcSQLiteConnection;
import io.javalin.http.Context;
import com.example.carparking.bean.Error;

import java.util.List;

public class BookingHandler {

    public static void addBooking(Context context) {
        BookingBean booking = context.bodyAsClass(BookingBean.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();

        db.insertBooking(booking.getLocation(), booking.getName(), booking.getParkingId(), booking.getStartTime(), booking.getEndTime(), booking.getStatus(), booking.getCarId());
        Error error = new Error();
        error.setError(false);
        error.setErrorMessage("Successful");
        context.json(error);
    }

    public static void getBooking(Context context) {
        BookingSelectBean booking = context.bodyAsClass(BookingSelectBean.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();

        List<BookingDTO> bookingList = db.selectBooking(booking.getStatus(), booking.getCarId());

        if (bookingList.size() == 0) {
            BookingResponse response = new BookingResponse();
            response.setBookingDTO(null);

            Error error = new Error();
            error.setErrorMessage("No bookings");
            error.setError(true);
            response.setError(error);
            context.json(response);
        } else {

            if(booking.getStatus().equalsIgnoreCase("ENDED")) {
                BookingResponseList response = new BookingResponseList();
                response.setBookingDTO(bookingList);

                Error error = new Error();
                error.setErrorMessage("Successful");
                error.setError(false);
                response.setError(error);
                context.json(response);
            } else {
                BookingDTO bookingDTO = bookingList.get(0);
                BookingResponse response = new BookingResponse();
                response.setBookingDTO(bookingDTO);

                Error error = new Error();
                error.setErrorMessage("Successful");
                error.setError(false);
                response.setError(error);
                context.json(response);
            }
        }
    }
}

package com.example.carparking;

import com.example.carparking.bean.*;
import com.example.carparking.bean.Error;
import com.example.carparking.database.JdbcSQLiteConnection;
import io.javalin.http.Context;

public class CarHandler {

    public static void addCar(Context context) {
        CarBean carBean = context.bodyAsClass(CarBean.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();

        db.insertCar(carBean.getMake(), carBean.getModel(), carBean.getRegistration(), carBean.getColor(), carBean.getUserId());
        Error error = new Error();
        error.setError(false);
        error.setErrorMessage("Successful");
        context.json(error);
    }

    public static void getCar(Context context) {
        UserId userId= context.bodyAsClass(UserId.class);

        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        Error error = new Error();
        CarResponseBean bean = new CarResponseBean();
        CarDTO carDTO = db.selectCar(userId.getUserId());
        if (carDTO == null) {
            error.setError(true);
            error.setErrorMessage("No cars found");
            bean.setCarDTO(null);
            bean.setError(error);
            context.json(bean);
        }else{
            error.setError(false);
            error.setErrorMessage("Successful");
            bean.setCarDTO(carDTO);
            bean.setError(error);
            context.json(bean);
        }
    }
}

package com.example.carparking;

import com.example.carparking.bean.BookingDTO;
import com.example.carparking.bean.Data;
import com.example.carparking.bean.UserDTO;
import com.example.carparking.bean.UserData;
import com.example.carparking.database.JdbcSQLiteConnection;
import io.javalin.http.Context;

import java.util.List;

public class HomePageHandler {
    public static void getData(Context context) {
        Data data = context.bodyAsClass(Data.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        List<BookingDTO> bookings = db.selectBooking("INITIATED",data.getCarId());
        context.json(bookings);
    }
}

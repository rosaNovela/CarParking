package com.example.carparking;

import com.example.carparking.bean.*;
import com.example.carparking.bean.Error;
import com.example.carparking.database.JdbcSQLiteConnection;
import io.javalin.http.Context;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class LoginHandler {

    public static void login(Context context) {
        System.out.println("---------------------------");
        UserData userData = context.bodyAsClass(UserData.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        UserDTO userDTO = db.selectUser(userData.getUsername());
        if (userDTO != null && userDTO.getPassword().equals(userData.getPassword())) {

            try {
                SecureRandom secureRandom = new SecureRandom();
                byte[] salt = new byte[16];
                secureRandom.nextBytes(salt);

                MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
                messageDigest.update(salt);
                byte[] hashedPassword = messageDigest.digest(userData.getPassword().getBytes(StandardCharsets.UTF_8));
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < hashedPassword.length; i++) {
                    stringBuilder.append(Integer.toString((hashedPassword[i] & 0xff) + 0x100, 16).substring(1));
                }

                Token token = setTokenResponse(stringBuilder.toString(), false, "Successful.", userDTO.getId());
                context.json(token);
            } catch (NoSuchAlgorithmException e) {
                Token token = setTokenResponse("", true, "Internal server error",0);
                e.printStackTrace();
                context.json(token);
            }

        } else {
            Token token = setTokenResponse("", true, "login failed.", 0);
            context.json(token);
        }
    }

    private static Token setTokenResponse(String token, boolean error, String errorMessage, int id) {
        Token tokenObject = new Token();
        tokenObject.setToken(token);
        tokenObject.setId(id);
        Error errorObject = new Error();
        errorObject.setError(error);
        errorObject.setErrorMessage(errorMessage);
        tokenObject.setError(errorObject);
        return tokenObject;
    }

    public static void signup(Context context) {
        User user = context.bodyAsClass(User.class);
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        db.insertUserData(user.getUsername(), user.getPassword(), user.getEmail(), user.getName());
        context.redirect("/index.html");
    }

    public static void signupWeb(Context context) {
        String username = context.formParam("username");
        String password = context.formParam("password");
        String name = context.formParam("name");
        String email = context.formParam("email");

        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        db.insertUserData(username, password, email, name);
        context.redirect("/index.html");
    }

    public static void loginweb(Context context) {
        String username = context.formParam("username");
        String password = context.formParam("password");
        context.redirect(validate(username, password) ? "signedin.html": "index.html");
    }

    private static boolean validate(String username, String password) {
        JdbcSQLiteConnection db = new JdbcSQLiteConnection();
        UserDTO userDTO = db.selectUser(username);
        if (userDTO == null)
            return false;
        if (userDTO.getPassword().equals(password)) {
            return true;
        } else {
            return false;
        }
    }
}

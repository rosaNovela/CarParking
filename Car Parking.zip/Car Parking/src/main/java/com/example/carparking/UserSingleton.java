package com.example.carparking;

public class UserSingleton {

}

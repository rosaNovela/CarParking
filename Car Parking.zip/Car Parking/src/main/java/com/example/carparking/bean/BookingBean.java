package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class BookingBean {

    private String location;
    private String name;
    private int parkingId;
    private String startTime;
    private String endTime;
    private String status;
    private int carId;

    @SuppressWarnings("unused")
    @JsonProperty("data")
    private void unpackData(JsonNode data) {
        this.location = data.get("location").asText();
        this.name = data.get("name").asText();
        this.parkingId = data.get("parkingId").asInt();
        this.startTime = data.get("startTime").asText();
        this.endTime = data.get("endTime").asText();
        this.status = data.get("status").asText();
        this.carId = data.get("carId").asInt();
    }

    public String getLocation() {
        return location;
    }

    public String getName() {
        return name;
    }

    public int getParkingId() {
        return parkingId;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getStatus() {
        return status;
    }

    public int getCarId() {
        return carId;
    }
}

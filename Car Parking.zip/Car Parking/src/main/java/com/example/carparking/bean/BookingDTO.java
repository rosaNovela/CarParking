package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class BookingDTO {

    private String location;
    private String name;
    private int parkingId;
    private String startTime;
    private String endTime;
    private String status;
    private int carId;


    public BookingDTO(String location, String name, int parkingId, String startTime, String endTime, String status, int carId) {
        this.location = location;
        this.name = name;
        this.parkingId = parkingId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.carId = carId;
    }

    public String getLocation() {
        return location;
    }

    public String getName() {
        return name;
    }

    public int getParkingId() {
        return parkingId;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getStatus() {
        return status;
    }

    public int getCarId() {
        return carId;
    }
}

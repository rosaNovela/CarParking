package com.example.carparking.bean;

import java.util.List;

public class BookingResponseList {

    private List<BookingDTO> bookingDTO;
    private Error error;

    public List<BookingDTO> getBookingDTO() {
        return bookingDTO;
    }

    public void setBookingDTO(List<BookingDTO> bookingDTO) {
        this.bookingDTO = bookingDTO;
    }

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }
}

package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class BookingSelectBean {

    private String status;
    private int carId;

    @JsonProperty("data")
    private void unpackData(JsonNode data) {
        this.status = data.get("status").asText();
        this.carId = data.get("carid").asInt();
    }

    public String getStatus() {
        return status;
    }

    public int getCarId() {
        return carId;
    }
}

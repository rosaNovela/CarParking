package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class CarBean {

    private String make;
    private String model;
    private String registration;
    private String color;
    private int userId;

    @SuppressWarnings("unused")
    @JsonProperty("data")
    private void unpackData(JsonNode data) {
        this.make = data.get("make").asText();
        this.model = data.get("model").asText();
        this.registration = data.get("registration").asText();
        this.color = data.get("color").asText();
        this.userId = data.get("userId").asInt();
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getRegistration() {
        return registration;
    }

    public String getColor() {
        return color;
    }

    public int getUserId() {
        return userId;
    }
}

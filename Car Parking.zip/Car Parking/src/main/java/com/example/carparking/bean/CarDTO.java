package com.example.carparking.bean;

public class CarDTO {

    private String make;
    private String model;
    private String registration;
    private String color;
    private int userId;
    private int carId;

    public CarDTO(String make, String model, String registration, String color, int userId, int cardId) {
        this.make = make;
        this.model = model;
        this.registration = registration;
        this.color = color;
        this.userId = userId;
        this.carId = cardId;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getRegistration() {
        return registration;
    }

    public String getColor() {
        return color;
    }

    public int getUserId() {
        return userId;
    }

    public int getCarId() {
        return carId;
    }
}

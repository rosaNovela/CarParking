package com.example.carparking.bean;

public class CarResponseBean {

    private CarDTO carDTO;
    private Error error;

    public CarDTO getCarDTO() {
        return carDTO;
    }

    public Error getError() {
        return error;
    }

    public void setCarDTO(CarDTO carDTO) {
        this.carDTO = carDTO;
    }

    public void setError(Error error) {
        this.error = error;
    }
}

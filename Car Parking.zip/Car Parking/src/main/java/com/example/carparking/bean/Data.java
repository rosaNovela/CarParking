package com.example.carparking.bean;

public class Data {

    private int userId;
    private int carId;

    public Data(int userId, int carId) {
        this.userId = userId;
        this.carId = carId;
    }

    public int getUserId() {
        return userId;
    }

    public int getCarId() {
        return carId;
    }
}

package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class User {

    private String password;
    private String username;
    private String name;
    private String email;

    @SuppressWarnings("unused")
    @JsonProperty("data")
    private void unpackData(JsonNode data) {
        this.username = data.get("username").asText();
        this.password = data.get("password").asText();
        this.email = data.get("email").asText();
        this.name = data.get("name").asText();
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}

package com.example.carparking.bean;

public class UserDTO {

    private String username;
    private String password;
    private int id;

    public UserDTO(String username, String password, int id) {
        this.password = password;
        this.username = username;
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getId() {
        return id;
    }
}

package com.example.carparking.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

public class UserId {
    private int userId;

    @JsonProperty("data")
    private void unpackData(JsonNode data) {
        this.userId = data.get("userid").asInt();
    }

    public int getUserId() {
        return userId;
    }
}

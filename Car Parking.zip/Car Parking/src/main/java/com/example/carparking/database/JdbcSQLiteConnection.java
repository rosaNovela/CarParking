package com.example.carparking.database;

import com.example.carparking.bean.BookingDTO;
import com.example.carparking.bean.CarDTO;
import com.example.carparking.bean.Data;
import com.example.carparking.bean.UserDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JdbcSQLiteConnection {
    Connection conn;
    private static final String INSERT_USER = "Insert into user(username, password, email, name) values(?,?,?,?)"; // created a string for inserting values into the db
    private static final String SELECT_USER_BY_USERNAME = "Select * from USER where username = ?";
    private static final String SELECT_USER_BY_ID = "Select * from USER where id = ?";
    private static final String SELECT_CAR_BY_ID = "Select * from CAR where user_id = ?";
    private static final String INSERT_CAR = "Insert into car(make, model, registration, color, user_id) values(?,?,?,?, ?)";
    private static final String SELECT_BOOKING_BY_STATUS = "Select * from BOOKING where status = ? AND car_id = ?";
    private static final String INSERT_BOOKING = "Insert into booking(location, name, parking_id, car_id, start_time, end_time, status) values(?,?,?,?,?,?,?)";

    public void connectToDB() {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db");
            Statement stmt = conn.createStatement();
            stmt.execute("create table IF NOT EXISTS USER(id INTEGER PRIMARY KEY AUTOINCREMENT, username VARCHAR(200),  password VARCHAR(200), email VARCHAR(200), name VARCHAR(200))");
            stmt.execute("create table IF NOT EXISTS CAR(id INTEGER PRIMARY KEY AUTOINCREMENT, make VARCHAR(200),  model VARCHAR(200), registration VARCHAR(200), color VARCHAR(200), user_id INTEGER, FOREIGN KEY(USER_ID) REFERENCES USER(ID))");
            stmt.execute("create table IF NOT EXISTS BOOKING(id INTEGER PRIMARY KEY AUTOINCREMENT, location VARCHAR(200), name VARCHAR(200), parking_id VARCHAR(200), car_id INTEGER, start_time VARCHAR(200), end_time VARCHAR(200), status VARCHAR(200), FOREIGN KEY(CAR_ID) REFERENCES CAR(ID))");

            if (conn != null) {
                System.out.println("Connected to the database");
                DatabaseMetaData dm = (DatabaseMetaData) conn.getMetaData();
                System.out.println("Driver name: " + dm.getDriverName());
                System.out.println("Driver version: " + dm.getDriverVersion());
                System.out.println("Product name: " + dm.getDatabaseProductName());
                System.out.println("Product version: " + dm.getDatabaseProductVersion());
            }
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection(); //created a method to check and close db connection if opened
        }
    }

    public void closeConnection() {  // method to check if database is connected and disconnect.
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void insertUserData(String username, String password, String email, String name) {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db");
            Statement stmt = conn.createStatement();

            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(INSERT_USER);
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setString(3, email);
                ps.setString(4, name);
                ps.executeUpdate();
            }
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    public void insertCar(String make, String model, String registration, String color, int userId) {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db");
            Statement stmt = conn.createStatement();

            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(INSERT_CAR);
                ps.setString(1, make);
                ps.setString(2, model);
                ps.setString(3, registration);
                ps.setString(4, color);
                ps.setInt(5, userId);
                ps.executeUpdate();
            }
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    public CarDTO selectCar(int carId) {
        try {
            CarDTO carDTO = null;
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db"); //reconnecting to database
            Statement stmt = conn.createStatement(); //preparing our insert statement.
            PreparedStatement ps = conn.prepareStatement(SELECT_CAR_BY_ID);
            ps.setInt(1, carId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int id = rs.getInt("id");
                String make = rs.getString("make");
                String model = rs.getString("model");
                String reg = rs.getString("registration");
                String color = rs.getString("color");
                int userId = rs.getInt("user_id");
                carDTO = new CarDTO(make, model, reg, color, userId, id);
            }
            return carDTO;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection(); //check and close connection if connected.
        }
        return null;
    }

    public UserDTO selectUser(String username) {
        try {
            UserDTO userDTO = null;
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db"); //reconnecting to database
            Statement stmt = conn.createStatement(); //preparing our insert statement.
            PreparedStatement ps = conn.prepareStatement(SELECT_USER_BY_USERNAME);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                String dbUsername = rs.getString("USERNAME");
                String dbPassword = rs.getString("PASSWORD");
                int id = rs.getInt("ID");
                userDTO = new UserDTO(dbUsername, dbPassword, id);
            }
            return userDTO;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection(); //check and close connection if connected.
        }
        return null;
    }

    public UserDTO selectUserById(int id) {
        try {
            UserDTO userDTO = null;
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db"); //reconnecting to database
            Statement stmt = conn.createStatement(); //preparing our insert statement.
            PreparedStatement ps = conn.prepareStatement(SELECT_USER_BY_ID);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                String dbUsername = rs.getString("USERNAME");
                String dbPassword = rs.getString("PASSWORD");
                int user_id = rs.getInt("ID");
                userDTO = new UserDTO(dbUsername, dbPassword, user_id);
            }
            return userDTO;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection(); //check and close connection if connected.
        }
        return null;
    }

    public List<BookingDTO> selectBooking(String status, int carId) {
        try {
            List<BookingDTO> list = new ArrayList<>();
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db"); //reconnecting to database
            Statement stmt = conn.createStatement(); //preparing our insert statement.
            PreparedStatement ps = conn.prepareStatement(SELECT_BOOKING_BY_STATUS);
            ps.setString(1, status);
            ps.setInt(2, carId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                String location = rs.getString("location");
                String name = rs.getString("name");
                String startTime = rs.getString("start_time");;
                String endTime = rs.getString("end_time");
                int parkingId = rs.getInt("parking_id");
                BookingDTO bookingDTO = new BookingDTO(location, name, parkingId, startTime, endTime, status, carId);
                list.add(bookingDTO);
            }
            return list;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection(); //check and close connection if connected.
        }
        return null;
    }

    public void insertBooking(String location, String name, int parkingId, String startTime, String endTime, String status, int carId) {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:product.db");
            Statement stmt = conn.createStatement();

            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(INSERT_BOOKING);
                ps.setString(1, location);
                ps.setString(2, name);
                ps.setInt(3, parkingId);
                ps.setInt(4, carId);
                ps.setString(5, startTime);
                ps.setString(6, endTime);
                ps.setString(7, status);
                ps.executeUpdate();
            }
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            closeConnection();
        }
    }
}

let form = document.getElementById('addbookingForm');

form.addEventListener("submit", (e) => {
    e.preventDefault();
        let userObj = JSON.parse(sessionStorage.user);
        let location = document.getElementsByName('location');
        let parking = document.getElementsByName('parking');
        let parkingId = document.getElementsByName('parkingId');
        let startTime = document.getElementsByName('startTime');
        let endTime = document.getElementsByName('endTime');

        if (location[0].value == "" || parking[0].value == "" || parkingId[0].value == "" || startTime[0].value == "" || endTime[0].value == "") {
             console.log('Error');
        } else {
            var obj;
             fetch('/add_booking',
                 {
                     method: 'POST',
                     header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                     body: JSON.stringify( {
                         "data": {
                             "carId": userObj.car_id,
                             "location": location[0].value,
                             "name": parking[0].value,
                             "parkingId": parkingId[0].value,
                             "startTime": startTime[0].value,
                             "endTime": endTime[0].value,
                             "status": "INITIATED"
                         }
                     })
             })
             .then(response => response.json())
             .then(data => {
                obj = data;
                if (obj.error.error == true) {
                    let errorMessage = document.getElementById('error');
                } else {
                    window.location.assign('/home.html');
                }
             });
        }
});
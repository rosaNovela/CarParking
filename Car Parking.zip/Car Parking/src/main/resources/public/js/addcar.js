let form = document.getElementById('addcarForm');

if (sessionStorage.user === undefined) {
    console.log('testing')
} else {
    let userObj = JSON.parse(sessionStorage.user);
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        let model = document.getElementsByName('model');
        let make = document.getElementsByName('make');
        let color = document.getElementsByName('color');
        let registration = document.getElementsByName('registration');

        if (model[0].value == "" || make[0].value == "" || color[0].value == "" || registration[0].value == "") {
             console.log('Error');
        } else {
            var obj;
             fetch('/add_car',
                 {
                     method: 'POST',
                     header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                     body: JSON.stringify( {
                         "data": {
                             "userId": userObj.user_id,
                             "make": make[0].value,
                             "model": model[0].value,
                             "color": color[0].value,
                             "registration": registration[0].value
                         }
                     })
             })
             .then(response => response.json())
             .then(data => {
                obj = data;
                if (obj.error.error == true) {
                    let errorMessage = document.getElementById('error');
                    errorMessage.innerHTML = obj.error.errorMessage;
                } else {
                    window.open("/home.html");
                }
             });
        }
    });
}


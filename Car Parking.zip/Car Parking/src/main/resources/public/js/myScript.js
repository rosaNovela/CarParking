let form = document.getElementById('loginForm');

form.addEventListener("submit", (e) => {
    e.preventDefault();

    let username = document.getElementsByName('username');
    let password = document.getElementsByName('password');

    if (username[0].value == "" || password[0].value == "") {
         console.log('Error');
    } else {
        var obj;
         fetch('/login',
             {
                 method: 'POST',
                 header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                 body: JSON.stringify( {
                     "data": {
                         "username": username[0].value,
                         "password": password[0].value
                     }
                 })
         })
         .then(response => response.json())
         .then(data => {
            obj = data;
            if (obj.error.error == true) {
                let errorMessage = document.getElementById('error');
                errorMessage.innerHTML = obj.error.errorMessage;
            } else {
                sessionStorage.user = JSON.stringify(
                {
                    token: obj.token,
                    user_id: obj.id
                });
                getCar();
            }
         });
    }
});

function getCar() {
    var obj;
    let userObj = JSON.parse(sessionStorage.user);
    console.log('get car')
    fetch('/car',
        {
            method: 'POST',
            header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                body: JSON.stringify( {
                     "data": {
                          "userid": userObj.user_id,
                          "token": userObj.token
                     }
                })
        })
        .then(response => response.json())
        .then(data => {
                    obj = data;
                    if (obj.error.error == true) {
                        window.location.assign('/addcar.html');
                    } else {
                        sessionStorage.user = JSON.stringify(
                               {
                                    token: userObj.token,
                                    user_id: userObj.user_id,
                                    car_id: obj.carDTO.carId
                               });
                        window.location.assign('/home.html');
                    }
        });
}
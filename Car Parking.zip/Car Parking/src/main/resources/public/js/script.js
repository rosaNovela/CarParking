let progressBar = document.querySelector(".progress_bar");
let progress = document.querySelector(".progress_value");

fetch('localhost:7070/get_user_data',
    {
        method: 'POST',
        header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
        body: JSON.stringify( {
            "data": {
                "user_id": 1;
                "car_id": 1;
            }
        })
        .then(response => response.json())
        .then(response => console.log(JSON.stringify(response)))
});
if (sessionStorage.user === undefined) {
    console.log('testing')
    window.location.assign('/index.html');
} else {
    let token = JSON.parse(sessionStorage.user);
    createList();
    getBooking();
    getCar();
    console.log(token);
    computeTimeInSeconds();
}

function getCar() {
    let userObj = JSON.parse(sessionStorage.user);
    var obj;
    fetch('/car',
            {
                method: 'POST',
                header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                    body: JSON.stringify( {
                         "data": {
                              "userid": userObj.user_id,
                              "token": userObj.token
                         }
                    })
            })
            .then(response => response.json())
            .then(data => {
                 obj = data;
                 if (obj.error.error == true) {

                 } else {
                    let car = obj.carDTO;

                    const div = document.getElementById('car_list');
                    const new_div = document.createElement('div');
                    const p = document.createElement('p');
                    p.style.margin = "10px";
                    p.style.backgroundColor = "#ffffff";
                    const node = document.createTextNode(car.make + " " + car.model);

                    p.appendChild(node);
                    new_div.appendChild(p);
                    div.appendChild(new_div);
                 }
            });
}

var startClock = 0;
var remainingTime = 0;

function computeTimeInSeconds(start, end) {
    const currentDate = new Date();
    const currentHour = currentDate.getHours();
    const currentMinute = currentDate.getMinutes();

    start = "07:05";
    end = "7:40";
    let startArr = start.toString().split(':');
    let startHour = parseInt(startArr[0]);
    let startMinute = parseInt(startArr[1]);

    let endArr = end.toString().split(':');
    let endHour = parseInt(endArr[0]);
    let endMinute = parseInt(endArr[1]);

    if (endHour < currentHour) {
        //end booking
    }

    var minutes = 0;

    if (startHour > currentHour || (startHour == currentHour && startMinute > currentMinute)) {
        if (startHour > currentHour)
            minutes = ((startHour - currentHour) * 60) + (startMinute - currentMinute);
        else
            minutes = startMinutes - currentMinute;
            startClock = minutes * 60;
        }
        var totalMinutes = 0;
        if (endHour != startHour)
            totalMinutes = ((endHour - startHour) * 60) + (endMinute - startMinute);
        else {
            totalMinutes = Math.abs(endMinute - startMinute);

        var totalm = totalMinutes * 60;
        document.getElementById("progress_id").max = `${totalm}`;
        var totalCurrentTimeMinutes = 0;

        if (currentHour != startHour)
            totalCurrentTimeMinutes = ((currentHour - startHour) * 60) + (currentMinute - startMinute);
        else {
            totalCurrentTimeMinutes = Math.abs(currentMinute - startMinute);
        }
        if (startClock != 0) {
            var total = totalCurrentTimeMinutes * 60;
            document.getElementById("progress_id").style.background = 'conic-gradient(#87CEEB ${total * 3.6}deg, rgb(240, 239, 239) 0deg)'
        }
        remainingTime = totalMinutes - totalCurrentTimeMinutes;
    }

    var minutes = 0;
    let progress = setInterval(() => {

            if(minutes == 0 && remainingTime > 0) {
                minutes = 60;
                remainingTime--;
            }
            if (startClock == 0) {
                //textView.setText(time + ":" + minutes);
                document.getElementById("progress_id").style.background = 'conic-gradient(#87CEEB ${1 + 3.6}deg , rgb(240, 239, 239) 0deg)';
                minutes--;
            } else {
                   //textView.setText(time + ":00");
                   startClock--;
            }
            if (remainingTime <= 0 && minutes <= 0) {
                clearInterval(progress);
            }
    }, 2000)
}

function getBooking() {
    let userObj = JSON.parse(sessionStorage.user);
        fetch('/booking',
             {
                 method: 'POST',
                 header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
                 body: JSON.stringify( {
                      "data": {
                            "carid": userObj.car_id,
                            "status": "INITIATED",
                      }
                 })
             })
             .then(response => response.json())
             .then(data => {
                 obj = data;
                 if (obj.error.error == true) {
                    const span = document.getElementById('parkingSpot');
                    const node = document.createTextNode('Parking Spot');
                    span.appendChild(node);
                 } else {
                     const span = document.getElementById('parkingSpot');
                     const node = document.createTextNode(obj.bookingDTO.location + " " + obj.bookingDTO.name);
                     span.appendChild(node);
                     computeTimeInSeconds(obj.bookingDTO.startTime + "", obj.bookingDTO.endTime + "")
                 }
             });
}

function createList() {
    let userObj = JSON.parse(sessionStorage.user);
    fetch('/booking',
         {
             method: 'POST',
             header: {'Accept': 'Application/json', 'Content-Type': 'Application/json'},
             body: JSON.stringify( {
                  "data": {
                        "carid": userObj.car_id,
                        "status": "ENDED",
                  }
             })
         })
         .then(response => response.json())
         .then(data => {
             obj = data;
             if (obj.error.error == true) {

             } else {

                let list = obj.bookingDTO;

                for (let i = 0; i < list.length; i++) {
                    let booking = list[i];

                    const div = document.getElementById('booking_list');
                    const new_div = document.createElement('div');
                    const p = document.createElement('p');
                    p.style.margin = "10px";
                    p.style.backgroundColor = "#ffffff";
                    const node = document.createTextNode(booking.location + " " + booking.name);

                    p.appendChild(node);
                    new_div.appendChild(p);
                    div.appendChild(new_div);
                }
             }
         });
}

function addBooking() {
    window.location.assign('/addbooking.html');
}